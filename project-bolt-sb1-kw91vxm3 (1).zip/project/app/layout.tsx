import type { Metadata } from 'next'
import './globals.css'

export const metadata: Metadata = {
  title: 'Delicious Bites - Premium Recipe Hub',
  description: 'Discover amazing recipes with beautiful presentations and detailed instructions',
  keywords: 'recipes, cooking, food, delicious, gourmet, kitchen',
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en">
      <body className="font-poppins bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-100 min-h-screen">
        {children}
      </body>
    </html>
  )
}