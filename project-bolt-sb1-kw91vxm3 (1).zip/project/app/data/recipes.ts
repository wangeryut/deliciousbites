export interface Recipe {
  id: string
  title: string
  description: string
  ingredients: string[]
  instructions: string
  prepTime?: string
  servings?: number
  category: 'breakfast' | 'lunch' | 'dinner' | 'dessert'
  image: string
  rating: number
  difficulty: number // 1-5 scale
}

export const recipes: Recipe[] = [
  // Breakfast
  {
    id: 'pancakes',
    title: 'Fluffy Buttermilk Pancakes',
    description: 'Light, airy pancakes that melt in your mouth with a golden crispy exterior and tender interior.',
    category: 'breakfast',
    prepTime: '15 mins',
    servings: 4,
    rating: 4.8,
    difficulty: 2,
    image: 'https://images.pexels.com/photos/376464/pexels-photo-376464.jpeg?auto=compress&cs=tinysrgb&w=800',
    ingredients: [
      '2 cups all-purpose flour',
      '2 tablespoons granulated sugar',
      '2 teaspoons baking powder',
      '1/2 teaspoon salt',
      '1 3/4 cups buttermilk',
      '2 large eggs',
      '1/4 cup melted butter',
      '1 teaspoon vanilla extract'
    ],
    instructions: 'In a large bowl, whisk together flour, sugar, baking powder, and salt. In another bowl, combine buttermilk, eggs, melted butter, and vanilla. Pour wet ingredients into dry ingredients and stir until just combined (don\'t overmix). Heat a griddle over medium heat and cook pancakes until bubbles form on surface, then flip and cook until golden brown.'
  },
  {
    id: 'avocado-toast',
    title: 'Gourmet Avocado Toast',
    description: 'Elevated avocado toast with perfectly poached eggs, microgreens, and a drizzle of sriracha.',
    category: 'breakfast',
    prepTime: '12 mins',
    servings: 2,
    rating: 4.6,
    difficulty: 2,
    image: 'https://images.pexels.com/photos/1351238/pexels-photo-1351238.jpeg?auto=compress&cs=tinysrgb&w=800',
    ingredients: [
      '2 slices artisan sourdough bread',
      '2 ripe avocados',
      '2 fresh eggs',
      '1 tablespoon white vinegar',
      'Microgreens for garnish',
      'Sea salt and black pepper',
      'Red pepper flakes',
      'Extra virgin olive oil'
    ],
    instructions: 'Toast bread until golden. Bring water to boil, add vinegar, and poach eggs for 3-4 minutes. Mash avocados with salt, pepper, and olive oil. Spread avocado mixture on toast, top with poached egg, microgreens, and red pepper flakes.'
  },

  // Lunch
  {
    id: 'herb-grilled-chicken',
    title: 'Mediterranean Herb Grilled Chicken',
    description: 'Juicy chicken breast marinated in Mediterranean herbs and grilled to perfection.',
    category: 'lunch',
    prepTime: '25 mins',
    servings: 4,
    rating: 4.7,
    difficulty: 3,
    image: 'https://images.pexels.com/photos/2338407/pexels-photo-2338407.jpeg?auto=compress&cs=tinysrgb&w=800',
    ingredients: [
      '4 boneless chicken breasts',
      '1/4 cup extra virgin olive oil',
      '3 cloves garlic, minced',
      '2 tablespoons fresh lemon juice',
      '1 tablespoon fresh oregano',
      '1 tablespoon fresh thyme',
      '1 teaspoon dried rosemary',
      'Salt and freshly ground black pepper'
    ],
    instructions: 'Combine olive oil, garlic, lemon juice, and herbs in a bowl. Marinate chicken for at least 30 minutes. Preheat grill to medium-high heat. Season chicken with salt and pepper. Grill for 6-7 minutes per side until internal temperature reaches 165°F. Let rest for 5 minutes before serving.'
  },
  {
    id: 'quinoa-salad',
    title: 'Rainbow Quinoa Power Salad',
    description: 'Nutrient-packed salad with colorful vegetables, quinoa, and a zesty lemon vinaigrette.',
    category: 'lunch',
    prepTime: '20 mins',
    servings: 4,
    rating: 4.5,
    difficulty: 1,
    image: 'https://images.pexels.com/photos/1640777/pexels-photo-1640777.jpeg?auto=compress&cs=tinysrgb&w=800',
    ingredients: [
      '1 cup quinoa, cooked and cooled',
      '2 cups mixed greens',
      '1 cup cherry tomatoes, halved',
      '1 cucumber, diced',
      '1/2 red onion, thinly sliced',
      '1/2 cup feta cheese, crumbled',
      '1/4 cup olive oil',
      '2 tablespoons lemon juice',
      'Fresh herbs (parsley, mint)'
    ],
    instructions: 'Cook quinoa according to package directions and let cool. Combine all vegetables and quinoa in a large bowl. Whisk together olive oil, lemon juice, salt, and pepper. Toss salad with dressing, top with feta and fresh herbs. Chill for 30 minutes before serving.'
  },

  // Dinner
  {
    id: 'truffle-alfredo',
    title: 'Truffle Alfredo Pasta',
    description: 'Luxurious fettuccine alfredo elevated with truffle oil and fresh parmesan.',
    category: 'dinner',
    prepTime: '30 mins',
    servings: 4,
    rating: 4.9,
    difficulty: 3,
    image: 'https://images.pexels.com/photos/1279330/pexels-photo-1279330.jpeg?auto=compress&cs=tinysrgb&w=800',
    ingredients: [
      '1 lb fresh fettuccine pasta',
      '1 cup heavy cream',
      '1 cup freshly grated Parmigiano-Reggiano',
      '4 tablespoons unsalted butter',
      '3 cloves garlic, minced',
      '2 tablespoons truffle oil',
      'Fresh black pepper',
      'Sea salt',
      'Fresh parsley for garnish'
    ],
    instructions: 'Cook fettuccine in salted boiling water until al dente. In a large pan, melt butter and sauté garlic for 1 minute. Add cream and simmer for 3 minutes. Remove from heat, add cheese gradually while whisking. Toss with pasta, drizzle with truffle oil, and garnish with parsley and black pepper.'
  },
  {
    id: 'wagyu-steak',
    title: 'Perfect Wagyu Ribeye',
    description: 'Premium wagyu ribeye steak cooked to perfection with herb butter and roasted garlic.',
    category: 'dinner',
    prepTime: '20 mins',
    servings: 2,
    rating: 5.0,
    difficulty: 4,
    image: 'https://images.pexels.com/photos/361184/asparagus-steak-veal-steak-veal-361184.jpeg?auto=compress&cs=tinysrgb&w=800',
    ingredients: [
      '2 wagyu ribeye steaks (1.5 inches thick)',
      'Coarse sea salt',
      'Freshly cracked black pepper',
      '4 tablespoons unsalted butter',
      '4 sprigs fresh thyme',
      '4 cloves garlic, crushed',
      '2 sprigs fresh rosemary'
    ],
    instructions: 'Let steaks reach room temperature for 45 minutes. Season generously with salt and pepper. Heat cast iron pan over high heat until smoking. Sear steaks 3-4 minutes per side. Add butter, herbs, and garlic, basting steaks with aromatic butter. Rest for 10 minutes before serving.'
  },

  // Dessert
  {
    id: 'molten-chocolate',
    title: 'Molten Chocolate Lava Cake',
    description: 'Decadent individual chocolate cakes with a flowing molten center, served with vanilla ice cream.',
    category: 'dessert',
    prepTime: '25 mins',
    servings: 4,
    rating: 4.9,
    difficulty: 4,
    image: 'https://images.pexels.com/photos/291528/pexels-photo-291528.jpeg?auto=compress&cs=tinysrgb&w=800',
    ingredients: [
      '4 oz dark chocolate (70% cocoa)',
      '4 tablespoons unsalted butter',
      '2 large eggs',
      '2 large egg yolks',
      '1/4 cup granulated sugar',
      '2 tablespoons all-purpose flour',
      'Pinch of salt',
      'Butter and cocoa powder for ramekins',
      'Vanilla ice cream for serving'
    ],
    instructions: 'Preheat oven to 425°F. Butter and dust ramekins with cocoa powder. Melt chocolate and butter in double boiler. Whisk eggs, egg yolks, and sugar until thick. Fold in chocolate mixture, then flour and salt. Divide among ramekins. Bake 12-14 minutes until edges are firm but center jiggles. Invert onto plates and serve immediately with ice cream.'
  },
  {
    id: 'tiramisu',
    title: 'Classic Italian Tiramisu',
    description: 'Authentic tiramisu with layers of coffee-soaked ladyfingers and mascarpone cream.',
    category: 'dessert',
    prepTime: '30 mins + chilling',
    servings: 8,
    rating: 4.8,
    difficulty: 3,
    image: 'https://images.pexels.com/photos/6880219/pexels-photo-6880219.jpeg?auto=compress&cs=tinysrgb&w=800',
    ingredients: [
      '6 egg yolks',
      '3/4 cup white sugar',
      '1 1/4 cups mascarpone cheese',
      '1 3/4 cups heavy cream',
      '2 packages ladyfinger cookies',
      '1 cup strong espresso, cooled',
      '3 tablespoons coffee liqueur',
      'Unsweetened cocoa powder for dusting'
    ],
    instructions: 'Whisk egg yolks and sugar until thick and pale. Add mascarpone and beat until smooth. Whip cream to stiff peaks and fold into mascarpone mixture. Combine espresso and liqueur. Quickly dip ladyfingers in coffee mixture and arrange in dish. Spread half the mascarpone mixture over cookies. Repeat layers. Refrigerate 4 hours or overnight. Dust with cocoa before serving.'
  }
]