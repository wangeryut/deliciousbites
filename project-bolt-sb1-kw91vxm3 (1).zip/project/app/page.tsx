'use client'

import { useState } from 'react'
import Header from './components/Header'
import Navigation from './components/Navigation'
import RecipeGrid from './components/RecipeGrid'
import Footer from './components/Footer'
import { recipes } from './data/recipes'

export default function Home() {
  const [activeCategory, setActiveCategory] = useState('breakfast')

  const filteredRecipes = recipes.filter(recipe => recipe.category === activeCategory)

  return (
    <main className="min-h-screen">
      <div className="container mx-auto px-4 py-8 max-w-7xl">
        <Header />
        <Navigation 
          activeCategory={activeCategory}
          onCategoryChange={setActiveCategory}
        />
        <RecipeGrid recipes={filteredRecipes} />
        <Footer />
      </div>
    </main>
  )
}