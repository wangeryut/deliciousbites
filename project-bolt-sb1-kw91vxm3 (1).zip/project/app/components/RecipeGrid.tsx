'use client'

import RecipeCard from './RecipeCard'
import { Recipe } from '../data/recipes'

interface RecipeGridProps {
  recipes: Recipe[]
}

export default function RecipeGrid({ recipes }: RecipeGridProps) {
  return (
    <section className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 mb-16">
      {recipes.map((recipe, index) => (
        <div
          key={recipe.id}
          className="opacity-0 animate-fade-in"
          style={{ animationDelay: `${index * 100}ms`, animationFillMode: 'forwards' }}
        >
          <RecipeCard recipe={recipe} />
        </div>
      ))}
    </section>
  )
}