'use client'

import { useState } from 'react'
import Image from 'next/image'
import { Clock, Users, ChevronDown, Star } from 'lucide-react'
import { Recipe } from '../data/recipes'

interface RecipeCardProps {
  recipe: Recipe
}

export default function RecipeCard({ recipe }: RecipeCardProps) {
  const [isExpanded, setIsExpanded] = useState(false)

  return (
    <div className="recipe-card-hover bg-white/90 backdrop-blur-sm rounded-3xl shadow-xl border border-white/50 overflow-hidden cursor-pointer">
      {/* Recipe Image */}
      <div className="relative h-64 overflow-hidden" onClick={() => setIsExpanded(!isExpanded)}>
        <Image
          src={recipe.image}
          alt={recipe.title}
          fill
          className="object-cover transition-transform duration-700 hover:scale-110"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/50 via-transparent to-transparent" />
        
        {/* Rating Badge */}
        <div className="absolute top-4 right-4 bg-white/90 backdrop-blur-sm rounded-full px-3 py-1 flex items-center gap-1">
          <Star className="w-4 h-4 text-yellow-500 fill-current" />
          <span className="text-sm font-semibold text-slate-700">{recipe.rating}</span>
        </div>
        
        {/* Category Badge */}
        <div className="absolute top-4 left-4 bg-gradient-to-r from-coral-500 to-coral-600 text-white px-3 py-1 rounded-full text-sm font-semibold capitalize">
          {recipe.category}
        </div>
      </div>

      {/* Card Content */}
      <div className="p-6">
        <div className="flex items-center justify-between mb-4" onClick={() => setIsExpanded(!isExpanded)}>
          <h3 className="text-2xl font-bold text-slate-800 leading-tight">{recipe.title}</h3>
          <div className={`transform transition-transform duration-300 ${isExpanded ? 'rotate-180' : ''}`}>
            <ChevronDown className="w-6 h-6 text-slate-600" />
          </div>
        </div>

        {/* Recipe Meta */}
        <div className="flex items-center gap-6 mb-4 text-slate-600">
          {recipe.prepTime && (
            <div className="flex items-center gap-2">
              <Clock className="w-5 h-5 text-coral-500" />
              <span className="font-medium">{recipe.prepTime}</span>
            </div>
          )}
          {recipe.servings && (
            <div className="flex items-center gap-2">
              <Users className="w-5 h-5 text-coral-500" />
              <span className="font-medium">{recipe.servings} servings</span>
            </div>
          )}
        </div>

        {/* Recipe Description */}
        <p className="text-slate-600 leading-relaxed mb-4">{recipe.description}</p>

        {/* Expanded Content */}
        <div className={`transition-all duration-300 ease-in-out ${
          isExpanded ? 'max-h-screen opacity-100' : 'max-h-0 opacity-0 overflow-hidden'
        }`}>
          <div className="space-y-6 border-t border-slate-200 pt-6">
            {/* Ingredients */}
            <div>
              <h4 className="text-lg font-bold text-slate-800 mb-3 flex items-center gap-2">
                <div className="w-2 h-2 bg-coral-500 rounded-full"></div>
                Ingredients
              </h4>
              <ul className="space-y-2">
                {recipe.ingredients.map((ingredient, index) => (
                  <li
                    key={index}
                    className="flex items-center gap-3 text-slate-700"
                  >
                    <div className="w-1.5 h-1.5 bg-coral-400 rounded-full flex-shrink-0"></div>
                    {ingredient}
                  </li>
                ))}
              </ul>
            </div>

            {/* Instructions */}
            <div>
              <h4 className="text-lg font-bold text-slate-800 mb-3 flex items-center gap-2">
                <div className="w-2 h-2 bg-coral-500 rounded-full"></div>
                Instructions
              </h4>
              <p className="text-slate-700 leading-relaxed bg-slate-50 p-4 rounded-xl">
                {recipe.instructions}
              </p>
            </div>

            {/* Difficulty Level */}
            <div className="flex items-center justify-between pt-4 border-t border-slate-200">
              <span className="text-slate-600 font-medium">Difficulty:</span>
              <div className="flex items-center gap-1">
                {[...Array(5)].map((_, i) => (
                  <div
                    key={i}
                    className={`w-2 h-2 rounded-full ${
                      i < recipe.difficulty ? 'bg-coral-500' : 'bg-slate-300'
                    }`}
                  />
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}