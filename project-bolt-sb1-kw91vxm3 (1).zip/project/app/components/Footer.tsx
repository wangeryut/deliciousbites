'use client'

import { Phone, Mail, Instagram, Heart, ChefHat } from 'lucide-react'

export default function Footer() {
  return (
    <footer className="mt-20 relative overflow-hidden">
      {/* Background decoration */}
      <div className="absolute inset-0 -z-10">
        <div className="absolute bottom-0 left-1/4 w-96 h-96 bg-gradient-to-r from-blue-400 to-purple-500 rounded-full mix-blend-multiply filter blur-3xl opacity-10"></div>
        <div className="absolute bottom-0 right-1/4 w-96 h-96 bg-gradient-to-r from-coral-400 to-pink-500 rounded-full mix-blend-multiply filter blur-3xl opacity-10"></div>
      </div>

      <div className="glass-effect rounded-3xl p-12 text-center shadow-2xl border border-white/20">
        {/* Logo and Title */}
        <div className="flex items-center justify-center gap-3 mb-8">
          <ChefHat className="w-8 h-8 text-coral-500" />
          <h3 className="text-3xl font-bold gradient-text">Delicious Bites</h3>
        </div>

        {/* Contact Information */}
        <div className="grid md:grid-cols-3 gap-8 mb-8">
          <div className="flex flex-col items-center gap-3 p-6 bg-white/50 rounded-2xl backdrop-blur-sm border border-white/30 hover:scale-105 transition-transform duration-300">
            <div className="w-12 h-12 bg-gradient-to-r from-coral-500 to-coral-600 rounded-full flex items-center justify-center">
              <Phone className="w-6 h-6 text-white" />
            </div>
            <div>
              <p className="text-slate-600 font-medium mb-1">Call Us</p>
              <a 
                href="tel:+923215999516"
                className="text-coral-600 hover:text-coral-700 font-bold text-lg transition-colors"
              >
                +92 321 5999516
              </a>
            </div>
          </div>

          <div className="flex flex-col items-center gap-3 p-6 bg-white/50 rounded-2xl backdrop-blur-sm border border-white/30 hover:scale-105 transition-transform duration-300">
            <div className="w-12 h-12 bg-gradient-to-r from-blue-500 to-blue-600 rounded-full flex items-center justify-center">
              <Mail className="w-6 h-6 text-white" />
            </div>
            <div>
              <p className="text-slate-600 font-medium mb-1">Email Us</p>
              <a 
                href="mailto:amnajunaid19202@gmail.com"
                className="text-blue-600 hover:text-blue-700 font-bold text-lg transition-colors break-all"
              >
                amnajunaid19202@gmail.com
              </a>
            </div>
          </div>

          <div className="flex flex-col items-center gap-3 p-6 bg-white/50 rounded-2xl backdrop-blur-sm border border-white/30 hover:scale-105 transition-transform duration-300">
            <div className="w-12 h-12 bg-gradient-to-r from-pink-500 to-pink-600 rounded-full flex items-center justify-center">
              <Instagram className="w-6 h-6 text-white" />
            </div>
            <div>
              <p className="text-slate-600 font-medium mb-1">Follow Us</p>
              <a 
                href="https://www.instagram.com/homemadefood1284?utm_source=ig_web_button_share_sheet&igsh=NGdlbnhlYzZ4cWxs"
                target="_blank"
                rel="noopener noreferrer"
                className="text-pink-600 hover:text-pink-700 font-bold text-lg transition-colors"
              >
                @homemadefood1284
              </a>
            </div>
          </div>
        </div>

        {/* Copyright */}
        <div className="border-t border-white/20 pt-8">
          <p className="text-slate-600 text-lg flex items-center justify-center gap-2">
            &copy; 2025 Delicious Bites. Made with 
            <Heart className="w-5 h-5 text-coral-500 fill-current" />
            for food lovers everywhere.
          </p>
        </div>
      </div>
    </footer>
  )
}