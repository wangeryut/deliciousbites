'use client'

import { ChefHat, Sparkles } from 'lucide-react'

export default function Header() {
  return (
    <header className="text-center mb-16 relative overflow-hidden">
      {/* Background decoration */}
      <div className="absolute inset-0 -z-10">
        <div className="absolute top-10 left-1/4 w-72 h-72 bg-gradient-to-r from-blue-400 to-purple-500 rounded-full mix-blend-multiply filter blur-xl opacity-20 animate-bounce-gentle"></div>
        <div className="absolute top-20 right-1/4 w-72 h-72 bg-gradient-to-r from-coral-400 to-pink-500 rounded-full mix-blend-multiply filter blur-xl opacity-20 animate-bounce-gentle" style={{ animationDelay: '1s' }}></div>
      </div>

      <div className="glass-effect rounded-3xl p-12 shadow-2xl border border-white/20">
        <div className="flex items-center justify-center gap-4 mb-6">
          <div className="animate-pulse">
            <ChefHat className="w-16 h-16 text-coral-500" />
          </div>
          <h1 className="text-6xl font-bold gradient-text">
            Delicious Bites
          </h1>
          <div className="animate-pulse">
            <Sparkles className="w-8 h-8 text-yellow-500" />
          </div>
        </div>
        
        <p className="text-2xl text-slate-600 font-medium">
          Your Premium Gateway to Culinary Excellence
        </p>
        
        <div className="mt-6 inline-flex items-center gap-2 bg-gradient-to-r from-coral-500 to-coral-600 text-white px-6 py-3 rounded-full font-semibold shadow-lg hover:shadow-xl transition-all duration-300 hover:scale-105">
          <Sparkles className="w-5 h-5" />
          Discover Amazing Recipes
        </div>
      </div>
    </header>
  )
}