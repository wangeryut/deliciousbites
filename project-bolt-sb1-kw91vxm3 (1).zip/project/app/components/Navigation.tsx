'use client'

import { useState } from 'react'
import { Coffee, Utensils, Moon, IceCream } from 'lucide-react'

interface NavigationProps {
  activeCategory: string
  onCategoryChange: (category: string) => void
}

const categories = [
  { id: 'breakfast', label: 'Breakfast', icon: Coffee, color: 'from-orange-400 to-amber-500' },
  { id: 'lunch', label: 'Lunch', icon: Utensils, color: 'from-green-400 to-emerald-500' },
  { id: 'dinner', label: 'Dinner', icon: Moon, color: 'from-purple-400 to-indigo-500' },
  { id: 'dessert', label: 'Dessert', icon: IceCream, color: 'from-pink-400 to-rose-500' },
]

export default function Navigation({ activeCategory, onCategoryChange }: NavigationProps) {
  return (
    <nav className="flex justify-center gap-6 mb-16 flex-wrap">
      {categories.map((category, index) => {
        const Icon = category.icon
        const isActive = activeCategory === category.id
        
        return (
          <button
            key={category.id}
            onClick={() => onCategoryChange(category.id)}
            className={`relative px-8 py-4 rounded-2xl font-semibold text-lg transition-all duration-300 shadow-lg hover:shadow-xl hover:scale-105 hover:-translate-y-1 ${
              isActive
                ? `bg-gradient-to-r ${category.color} text-white shadow-2xl`
                : 'bg-white/80 backdrop-blur-sm text-slate-700 hover:bg-white border border-white/50'
            }`}
          >
            <div className="flex items-center gap-3">
              <Icon className={`w-6 h-6 ${isActive ? 'text-white' : 'text-slate-600'}`} />
              {category.label}
            </div>
            
            {isActive && (
              <div className="absolute inset-0 bg-gradient-to-r from-white/20 to-white/10 rounded-2xl" />
            )}
          </button>
        )
      })}
    </nav>
  )
}