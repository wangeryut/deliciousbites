# Delicious Bites - Premium Recipe Hub

A beautiful, responsive recipe website built with Next.js, TypeScript, and Tailwind CSS.

## Features

- 🍳 Beautiful recipe cards with detailed ingredients and instructions
- 📱 Fully responsive design
- 🎨 Modern glass-morphism UI with smooth animations
- 🔍 Category-based recipe filtering (Breakfast, Lunch, Dinner, Dessert)
- ⭐ Recipe ratings and difficulty levels
- 📧 Contact information and social media links

## Tech Stack

- **Framework**: Next.js 14 with TypeScript
- **Styling**: Tailwind CSS
- **Icons**: Lucide React
- **Deployment**: GitHub Pages / Netlify

## Getting Started

1. Clone the repository:
```bash
git clone <your-repo-url>
cd delicious-bites-nextjs
```

2. Install dependencies:
```bash
npm install
```

3. Run the development server:
```bash
npm run dev
```

4. Open [http://localhost:3000](http://localhost:3000) in your browser.

## Deployment

### GitHub Pages
This project is configured for automatic deployment to GitHub Pages via GitHub Actions. Simply push to the `main` branch and the site will be deployed automatically.

### Netlify
You can also deploy to Netlify by connecting your GitHub repository to Netlify.

## Project Structure

```
├── app/
│   ├── components/          # React components
│   ├── data/               # Recipe data
│   ├── globals.css         # Global styles
│   ├── layout.tsx          # Root layout
│   └── page.tsx            # Home page
├── public/                 # Static assets
└── next.config.js          # Next.js configuration
```

## Contact

- 📞 Phone: +92 321 5999516
- 📧 Email: amnajunaid19202@gmail.com
- 📱 Instagram: [@homemadefood1284](https://www.instagram.com/homemadefood1284)

## License

This project is open source and available under the [MIT License](LICENSE).